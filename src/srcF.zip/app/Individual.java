
public class Individual {
    String adn;
    
    public Individual(String s){
        adn=s;
    }
}
